

function validateForm()
{

    var fname=document.forms["Admin_Form"]["firstname"].value;
    var lname=document.forms["Admin_Form"]["lastname"].value;
    var age=document.forms["Admin_Form"]["age"].value;
    var contact=document.forms["Admin_Form"]["contact"].value;
    var dob=document.forms["Admin_Form"]["dob"].value;
    var gender=document.forms["Admin_Form"]["gender"].value;
    var pwd=document.forms["Admin_Form"]["password"].value;
    var Email=document.forms["Admin_Form"]["email"].value;

   if(fname=="")
   {
       alert("First name must be filled out");
       return false;
   }
   else if(lname==" ")
   {
       alert("Last name must be filled out");
       return false;
   }
   else if(age="")
   {
       alert("age must be filled out");
   }
   else if(contact="")
   {
       alert("Contact number must be filled out");
   }
   else if(dob=="")
   {
       alert("Date of birth must be filled out");
   }
   else if(gender=="")
   {
       alert("Gender must be filled out");
   }
   else if(password=="")
   {
       alert("Password must be filled out");
   }

   else if(email=="")
   {
       alert("Email must be filled out")
   }
   else
   {
       alert("");
   }

}