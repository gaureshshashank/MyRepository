# Trainer_pool_management

Hello BOIS
